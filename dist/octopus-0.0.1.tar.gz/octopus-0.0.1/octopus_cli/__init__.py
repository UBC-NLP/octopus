
from octopus import *
from octopus.copyright import *

__author__ = author
__copyright__ = copyright
__license__ = license
__version__ = version
__email__ = email
__status__ = status